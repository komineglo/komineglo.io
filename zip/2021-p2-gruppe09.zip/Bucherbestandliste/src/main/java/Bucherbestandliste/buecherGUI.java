/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bucherbestandliste;

import Bucherbestandliste.Controller;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.*;
import java.text.DecimalFormat;
import java.io.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class buecherGUI extends JFrame {

    Controller controller = new Controller();
    //declaration
    private String title;
    private String p1,p2;
    private long isbn;
    private boolean stock;
    //decial format
    private double price;
    private final DecimalFormat df = new DecimalFormat("#.##");

    //filechooser
    private final JFileChooser filechooser = new JFileChooser(new File("."));
    //GUI Elements
    private final JPanel centerPanel = new JPanel();
    private final JPanel bottomPanel = new JPanel();
    private final JPanel leftPanel = new JPanel();
    private final JPanel gridtop = new JPanel();
    private final JPanel gridcenter = new JPanel();
    private final JPanel flowtf1 = new JPanel();
    private final JPanel flowtf2 = new JPanel();
    private final JPanel flowtf3 = new JPanel();
    private final JTable table;
    private final JScrollPane sp;
    private final JCheckBox checkbox = new JCheckBox();
    //Buttons
    private final JButton enterbtn = new JButton("Enter");
    private final JButton clearbtn = new JButton("Clear");
    private final JButton updatebtn = new JButton("Update");
    private final JButton savebtn = new JButton("Save");
    private final JButton loadbtn = new JButton("Load");
    //Labels
    private final JLabel isbnlb = new JLabel("ISBN");
    private final JLabel titlelb = new JLabel("Title");
    private final JLabel pricelb = new JLabel("Price");
    private final JLabel stocklb = new JLabel("Stock");
    //Textfields
    private final JTextField isbntf = new JTextField("", 10);
    private final JTextField titletf = new JTextField("", 10);
    private final JTextField pricetf = new JTextField("", 10);

    //save Method beginns here
    private void saveT() {
        if (filechooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            controller.saveT(filechooser.getSelectedFile());
        }
    }
    // save Method ends here

    //load method begins here
    private void loadT() {
        if (filechooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            controller.loadT(filechooser.getSelectedFile());
        }
    }
    //load method ends here

    //Reset Method
    public void reset() {
        isbntf.setText("");
        titletf.setText("");
        pricetf.setText("");
        stock = false;
        checkbox.setSelected(stock);
    }

    public buecherGUI() {
        setTitle("Buecherbestandsliste");
        setSize(800, 600);
        //manuelly creating Table Model
        table = new JTable(controller.getModel()) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        sp = new JScrollPane(table);
        //Layout
        centerPanel.setLayout(new BorderLayout());
        leftPanel.setLayout(new BorderLayout());
        gridtop.setLayout(new GridLayout(0, 2));
        gridcenter.setLayout(new GridLayout(0, 1));
        flowtf1.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 45));
        flowtf2.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 45));
        flowtf3.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 45));

        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
        add(leftPanel, BorderLayout.WEST);

        centerPanel.add(sp, BorderLayout.CENTER);

        //add Buttons
        gridcenter.add(enterbtn);
        gridcenter.add(clearbtn);
        gridcenter.add(updatebtn);
        gridcenter.add(savebtn);
        gridcenter.add(loadbtn);

        //layouts Schachtelung           
        gridtop.add(isbnlb);
        flowtf1.add(isbntf);
        gridtop.add(flowtf1);

        gridtop.add(titlelb);
        flowtf2.add(titletf);
        gridtop.add(flowtf2);

        gridtop.add(pricelb);
        flowtf3.add(pricetf);
        gridtop.add(flowtf3);

        gridtop.add(stocklb);
        gridtop.add(checkbox);

        leftPanel.add(gridtop, BorderLayout.CENTER);
        leftPanel.add(gridcenter, BorderLayout.SOUTH);

        //ActionListener as anoyme Class
        enterbtn.addActionListener(new java.awt.event.ActionListener() {
            //call ActionPerformed
            public void actionPerformed(java.awt.event.ActionEvent e) {
                if (isbntf.getText().equals("") || titletf.getText().equals("") || pricetf.getText().equals("")) {
                    JOptionPane.showMessageDialog((JButton) e.getSource(), "Bitte alle Felder ausfüllen");
                } else {
                    //Safe ISBN String temp.
                    p1 = isbntf.getText();
                    p2 = pricetf.getText();
                    //error handling
                    try {
                        //convert String into Integer
                        //Use Long Integer, because Integer [--2147483648,2147483647]
                        isbn = Long.parseLong(p1.trim()); //remove whitespace of String at Begin and Ende
                    } catch (NumberFormatException ex) {
                        System.out.println("ISBN: not a Number");
                    }
                    //error ends
                    title = titletf.getText();
                    //same like ISBN String
                    p2 = pricetf.getText();
                    //error handling
                    try {
                        //neagtive zahlen müssen überprüft werden, und exception output
                        price = Double.parseDouble(p2.trim());
                        price = Double.valueOf(df.format(price));
                        //check if price is negative                
                    } catch (NumberFormatException ex) {
                        System.out.println("not a number price");
                    }
                    //error ends    
                    //not nessesary
                    //Boolean war vorraussetzung, nicht sicher ob nur checkbox anfrage gereicht hätte
                    if (checkbox.isSelected()) {
                        stock = true;
                    } else {
                        stock = false;
                    }
                    Book b = null;
                    if (stock) {
                        b = new Book(isbn, title, price, " Yes ");
                        controller.insert(b);
                    } else {
                        b = new Book(isbn, title, price, " No ");
                        controller.insert(b);
                    }
                    reset();
                }
            }
        });

        clearbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                if (table.getSelectedRowCount() == 1) {
                    controller.clear(table.getSelectedRow());
                    reset();
                } else {
                    // Wenn, die Tabelle leer ist
                    if (table.getRowCount() == 0) {
                        JOptionPane.showMessageDialog((JButton) e.getSource(), "Die Tabelle ist leer");
                    } else {
                        //Wenn die Tabelle nicht leer ist und kein oder mehrere Bücher ausgewählt wurden
                        JOptionPane.showMessageDialog((JButton) e.getSource(), "Bitte wählen Sie nur ein Buch aus.");
                    }
                }
            }
        });

        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                if (table.getSelectedRowCount() == 1) {
                    // Wenn eine Spalte ausgewählt ist
                    isbntf.getText();
                    titletf.getText();
                    pricetf.getText();
                    if (checkbox.isSelected()) {
                        stock = true;
                    } else {
                        stock = false;
                    }
                    Book book = new Book(Long.parseLong(isbntf.getText()),titletf.getText(),
                            Double.parseDouble(pricetf.getText()), "NA");
                    if (stock) {
                        book.setStock("Yes");
                    } else {
                        book.setStock("No");
                    }
                    controller.update(book, table.getSelectedRow());
                    // popup update erfolgreich         
                    reset();
                } else {
                    if (table.getRowCount() == 0) {
                        JOptionPane.showMessageDialog((JButton) e.getSource(), "Die Tabelle leer");
                    } else {
                        //Wenn die Tabelle nicht leer ist und kein oder mehrere Bücher ausgewählt wurden
                        JOptionPane.showMessageDialog((JButton) e.getSource(), "Bitte wählen Sie nur ein Buch aus.");
                    }
                }
            }
        });

        savebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                saveT();
            }
        });

        loadbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                loadT();
            }
        });

        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                Book book = controller.getClickedBook(table.getSelectedRow());
                isbntf.setText(book.getISBN()+"");
                titletf.setText(book.getTitle());
                pricetf.setText(book.getPrice() + "");
            }
        });
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}