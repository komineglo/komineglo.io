/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bucherbestandliste;

import java.io.*;
import java.util.Iterator;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

public class Controller {

    //Setup table
    private DefaultTableModel model;
    //T-Data-column
    String[] columns = {"ISBN", "Title", "Price", "Stock"};
    //T-Data
    Object[][] data = {};

    public Controller() {
        model = new DefaultTableModel(data, columns);
    }

    public DefaultTableModel getModel() {
        return this.model;
    }

    public void saveT(File file) {
        //error handling
        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
            out.writeObject(model.getDataVector());
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadT(File file) {
        //error handling
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
            Vector rowData = (Vector) in.readObject();
            model.setRowCount(0);
            Iterator it = rowData.iterator();

            while (it.hasNext()) {
                model.addRow((Vector) it.next());
            }
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Book getClickedBook(int index) {
        String isbn = model.getValueAt(index, 0).toString();
        String title = model.getValueAt(index, 1).toString();
        String price = model.getValueAt(index, 2).toString();
        String stock = model.getValueAt(index, 3).toString();
        return new Book(Long.parseLong(isbn), title, Double.parseDouble(price), stock);
    }

    public void insert(Book book) {
        model.insertRow(model.getRowCount(), new Object[]{book.getISBN(), book.getTitle(), book.getPrice(), book.getStock()});
    }
    
    public void update(Book book, int index) {
        // set Update value in der Tabelle
        model.setValueAt(book.getISBN(), index, 0);
        model.setValueAt(book.getTitle(), index, 1);
        model.setValueAt(book.getPrice(), index, 2);
        model.setValueAt(book.getStock(), index, 3);
    }

    public void clear(int index) {
        model.removeRow(index);
    }
}
